Lab 01 submission prepared 2026-10-16 (Asia/Bangkok).
Students: 24120293_24120347_24120468
Baseline: 79e8024d61c3dd92ccf064fc67bb99cb999f70ab
Code commit: 35ba531d8f28cb6400182b408e0676299386fcdb
The patch reconstructed committed source byte for byte.
Clean build and all 17 selected test groups passed before make clean.
Report source and final evidence were added after cleaning code.
Task.md and original handoff notes preserve the historical code-stage plan;
this file records the final packaging status.
Original report experiments were run 2026-10-15; packaging checks are newer.
Build: make -j4 kernel/kernel fs.img
Tests: make check-lab01
Report: cd docs/report-source && tectonic OS1Lab_Report.tex
PDF validation from source root (requires PyMuPDF):
python3 tools/validate-report.py /path/to/submitted_Report.pdf --tex docs/report-source/OS1Lab_Report.tex
No upload to MOODLE has been performed.
