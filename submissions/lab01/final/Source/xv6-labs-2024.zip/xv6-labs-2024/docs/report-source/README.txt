Editable report source, university logo and figure assets.
Compile from this directory: tectonic OS1Lab_Report.tex
The submitted report PDF is at the top level of the outer ZIP.
Evidence and validation tools are under the xv6 source root.
